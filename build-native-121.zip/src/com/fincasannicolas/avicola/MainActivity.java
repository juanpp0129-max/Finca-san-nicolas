package com.fincasannicolas.avicola;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.print.PrintManager;
import android.webkit.*;
import android.widget.Toast;
import java.io.*;
import java.nio.charset.StandardCharsets;

public class MainActivity extends Activity {
    private static final String HOST = "appassets.androidplatform.net";
    private static final String ORIGIN = "https://" + HOST + "/";
    private static final int OPEN = 1, SAVE = 2;
    private WebView web;
    private Updates updates;
    private Thermometer sensor;
    private ValueCallback<Uri[]> picker;
    private byte[] pendingExport;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        updates = new Updates(this);
        sensor = new Thermometer(this);
        web = new WebView(this);
        setContentView(web);
        WebSettings settings = web.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(true);
        web.addJavascriptInterface(new DeviceActions(), "FincaAndroid");
        web.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (picker != null) picker.onReceiveValue(null);
                picker = callback;
                Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("*/*");
                try { startActivityForResult(intent, OPEN); }
                catch (android.content.ActivityNotFoundException error) {
                    picker.onReceiveValue(null);
                    picker = null;
                }
                return true;
            }
        });
        web.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return !isLocal(request.getUrl());
            }
            @Override public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                if (!isLocal(uri)) {
                    if ("https".equals(uri.getScheme()) && ("api.open-meteo.com".equals(uri.getHost()) || "geocoding-api.open-meteo.com".equals(uri.getHost()))) return null;
                    return missing();
                }
                String path = uri.getPath();
                if (path == null || !path.matches("/[a-zA-Z0-9_./-]+") || path.contains("..")) return missing();
                String type = path.endsWith(".html") ? "text/html" : path.endsWith(".js") ? "text/javascript"
                    : path.endsWith(".png") ? "image/png" : path.endsWith(".svg") ? "image/svg+xml" : "application/json";
                try { return new WebResourceResponse(type, "UTF-8", getAssets().open(path.substring(1))); }
                catch (IOException error) { return missing(); }
            }
        });
        web.loadUrl(ORIGIN + "index.html");
    }

    private static boolean isLocal(Uri uri) {
        return "https".equals(uri.getScheme()) && HOST.equals(uri.getHost()) && uri.getPort() == -1;
    }

    private static WebResourceResponse missing() {
        return new WebResourceResponse("text/plain", "UTF-8", 404, "Not found", java.util.Collections.emptyMap(), new ByteArrayInputStream(new byte[0]));
    }

    private void notifyUser(String message) {
        Toast.makeText(this, message, Toast.LENGTH_LONG).show();
    }

    // Native back: close the current web panel or return to the previous screen first.
    @Override public void onBackPressed() {
        if (web == null) { super.onBackPressed(); return; }
        web.evaluateJavascript("typeof androidBackRecord === 'function' && androidBackRecord()", result -> {
            if ("true".equals(result)) return;
            new android.app.AlertDialog.Builder(this)
                .setTitle("Cerrar Finca San Nicolás")
                .setMessage("¿Quieres salir de la aplicación?")
                .setNegativeButton("Cancelar", null)
                .setPositiveButton("Salir", (dialog, which) -> finish())
                .show();
        });
    }

    @Override public void onRequestPermissionsResult(int code, String[] permissions, int[] results) {
        super.onRequestPermissionsResult(code, permissions, results);
        if (code == Thermometer.PERMISSION && results.length > 0 && results[0] == android.content.pm.PackageManager.PERMISSION_GRANTED) sensor.choose();
    }
    @Override protected void onDestroy() { sensor.close(); super.onDestroy(); }

    public class DeviceActions {
        @JavascriptInterface public void setHomeIcon(String photo, boolean requestPin) {
            runOnUiThread(() -> updateHomeShortcut(photo, requestPin));
        }
        @JavascriptInterface public void readThermometer() { runOnUiThread(() -> sensor.choose()); }
        @JavascriptInterface public void update() { runOnUiThread(() -> updates.show()); }
        @JavascriptInterface public void exportFile(String name, String mime, String data) {
            if (!(name.endsWith(".json") || name.endsWith(".ics"))) return;
            runOnUiThread(() -> {
                if (pendingExport != null) return;
                pendingExport = data.getBytes(StandardCharsets.UTF_8);
                Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType(mime).putExtra(Intent.EXTRA_TITLE, name);
                try { startActivityForResult(intent, SAVE); }
                catch (android.content.ActivityNotFoundException error) {
                    pendingExport = null;
                    notifyUser("No se pudo abrir Archivos");
                }
            });
        }
        @JavascriptInterface public void print() {
            runOnUiThread(() -> getSystemService(PrintManager.class).print("Etiqueta Finca San Nicolás", web.createPrintDocumentAdapter("Etiqueta"), null));
        }
    }

    // Only an explicitly requested pin may create a shortcut. Other calls update an existing shortcut.
    private void updateHomeShortcut(String photo, boolean requestPin) {
        if (android.os.Build.VERSION.SDK_INT < 26) {
            if (requestPin) notifyUser("Tu versión de Android no admite este acceso directo.");
            return;
        }
        try {
            android.content.pm.ShortcutManager manager = getSystemService(android.content.pm.ShortcutManager.class);
            if (manager == null) { if (requestPin) notifyUser("Accesos directos no disponibles."); return; }
            final String id = "finca-profile-home";
            boolean pinned = false;
            for (android.content.pm.ShortcutInfo item : manager.getPinnedShortcuts()) {
                if (id.equals(item.getId())) { pinned = true; break; }
            }
            if (!pinned && !requestPin) return;
            android.graphics.drawable.Icon icon;
            if (photo == null || photo.isEmpty()) {
                icon = android.graphics.drawable.Icon.createWithResource(this, getApplicationInfo().icon);
            } else {
                final String prefix = "data:image/jpeg;base64,";
                if (!photo.startsWith(prefix) || photo.length() >= 400000) throw new IllegalArgumentException("Foto inválida");
                byte[] data = android.util.Base64.decode(photo.substring(prefix.length()), android.util.Base64.DEFAULT);
                android.graphics.BitmapFactory.Options bounds = new android.graphics.BitmapFactory.Options();
                bounds.inJustDecodeBounds = true;
                android.graphics.BitmapFactory.decodeByteArray(data, 0, data.length, bounds);
                if (bounds.outWidth <= 0 || bounds.outHeight <= 0 || bounds.outWidth > 640 || bounds.outHeight > 640) throw new IllegalArgumentException("Foto inválida");
                android.graphics.Bitmap bitmap = android.graphics.BitmapFactory.decodeByteArray(data, 0, data.length);
                if (bitmap == null) throw new IllegalArgumentException("Foto inválida");
                int size = Math.min(320, Math.min(manager.getIconMaxWidth(), manager.getIconMaxHeight()));
                if (size > 0) bitmap = android.graphics.Bitmap.createScaledBitmap(bitmap, size, size, true);
                icon = android.graphics.drawable.Icon.createWithBitmap(bitmap);
            }
            Intent launch = new Intent(this, MainActivity.class).setAction(Intent.ACTION_VIEW)
                .addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
            android.content.pm.ShortcutInfo shortcut = new android.content.pm.ShortcutInfo.Builder(this, id)
                .setShortLabel("Finca San Nicolás").setLongLabel("Finca San Nicolás")
                .setIcon(icon).setIntent(launch).build();
            if (pinned) {
                boolean ok = manager.updateShortcuts(java.util.Collections.singletonList(shortcut));
                if (requestPin) notifyUser(ok ? "Icono personalizado actualizado." : "Android no permitió actualizar el icono.");
            } else if (!manager.isRequestPinShortcutSupported()) {
                notifyUser("La pantalla de inicio no admite accesos directos personalizados.");
            } else if (!manager.requestPinShortcut(shortcut, null)) {
                notifyUser("No se pudo solicitar el acceso directo.");
            }
        } catch (RuntimeException error) {
            if (requestPin) notifyUser("No se pudo preparar el icono personalizado.");
        }
    }

    @Override protected void onActivityResult(int code, int result, Intent data) {
        super.onActivityResult(code, result, data);
        if (code == OPEN && picker != null) {
            picker.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(result, data));
            picker = null;
        }
        if (code == SAVE) {
            byte[] bytes = pendingExport;
            pendingExport = null;
            if (result != RESULT_OK || data == null || data.getData() == null || bytes == null) return;
            try (OutputStream out = getContentResolver().openOutputStream(data.getData(), "w")) {
                if (out == null) throw new IOException();
                out.write(bytes);
                notifyUser("Archivo guardado");
            } catch (IOException error) { notifyUser("No se pudo guardar el archivo"); }
        }
    }
}
