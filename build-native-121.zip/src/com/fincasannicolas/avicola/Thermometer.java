package com.fincasannicolas.avicola;

import android.app.Activity;
import android.app.AlertDialog;
import android.bluetooth.*;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Handler;
import android.provider.Settings;
import java.util.*;
import java.text.NumberFormat;

final class Thermometer {
    static final int PERMISSION = 711;
    private static final String CONNECT = "android.permission.BLUETOOTH_CONNECT";
    private static final UUID SERVICE = UUID.fromString("0000181a-0000-1000-8000-00805f9b34fb");
    private static final UUID TEMP = UUID.fromString("00002a6e-0000-1000-8000-00805f9b34fb");
    private final Activity activity;
    private final Handler handler;
    private BluetoothGatt active;
    Thermometer(Activity activity) {
        this.activity = activity;
        handler = new Handler(activity.getMainLooper());
    }
    private void message(String text) {
        if (!activity.isFinishing() && !activity.isDestroyed())
            new AlertDialog.Builder(activity).setTitle("Termómetro Bluetooth").setMessage(text).setPositiveButton("Aceptar", null).show();
    }
    void choose() {
        if (Build.VERSION.SDK_INT >= 31 && activity.checkSelfPermission(CONNECT) != PackageManager.PERMISSION_GRANTED) {
            activity.requestPermissions(new String[]{CONNECT}, PERMISSION);
            return;
        }
        BluetoothManager manager = activity.getSystemService(BluetoothManager.class);
        BluetoothAdapter adapter = manager == null ? null : manager.getAdapter();
        if (adapter == null) { message("Bluetooth no disponible en este equipo."); return; }
        try {
            List<BluetoothDevice> list = new ArrayList<>(adapter.getBondedDevices());
            String[] names = new String[list.size()];
            for (int i=0;i<names.length;i++) {
                BluetoothDevice device = list.get(i);
                names[i] = (device.getName()==null?"Dispositivo":device.getName())+" · "+device.getAddress();
            }
            AlertDialog.Builder picker=new AlertDialog.Builder(activity).setTitle("Elegir termómetro")
                .setNeutralButton("Vincular en Android",(dialog,which)->activity.startActivity(new Intent(Settings.ACTION_BLUETOOTH_SETTINGS)))
                .setNegativeButton("Cancelar",null);
            if (!adapter.isEnabled() || list.isEmpty()) picker.setMessage("Activa Bluetooth y vincula el termómetro en Android. Luego vuelve a Leer termómetro.");
            else picker.setItems(names,(dialog,i)->read(list.get(i)));
            picker.show();
        } catch (SecurityException e) { message("Se necesita permiso para conectar el termómetro."); }
    }
    void close() {
        handler.removeCallbacksAndMessages(null);
        BluetoothGatt old=active; active=null;
        if(old!=null) try {old.close();} catch(SecurityException ignored) {}
    }
    private void finish(BluetoothGatt g,String text) {
        if(active==g){close();message(text);}
    }
    private void read(BluetoothDevice device) {
        close();
        BluetoothGattCallback callback=new BluetoothGattCallback(){
            @Override public void onConnectionStateChange(BluetoothGatt g,int status,int state){
                handler.post(()->{
                    if(active!=g)return;
                    if(status!=0 || state==BluetoothProfile.STATE_DISCONNECTED){finish(g,"No se pudo mantener la conexión.");return;}
                    try {if(state==BluetoothProfile.STATE_CONNECTED && !g.discoverServices())finish(g,"No se pudo consultar el sensor.");}
                    catch(SecurityException e){finish(g,"Permiso Bluetooth revocado.");}
                });
            }
            @Override public void onServicesDiscovered(BluetoothGatt g,int status){
                handler.post(()->{
                    if(active!=g)return;
                    BluetoothGattService service=g.getService(SERVICE);
                    BluetoothGattCharacteristic c=service==null?null:service.getCharacteristic(TEMP);
                    try {if(status!=0 || c==null || !g.readCharacteristic(c))finish(g,"Este dispositivo no ofrece lectura de temperatura ambiental BLE compatible.");}
                    catch(SecurityException e){finish(g,"Permiso Bluetooth revocado.");}
                });
            }
            @Override public void onCharacteristicRead(BluetoothGatt g,BluetoothGattCharacteristic c,int status){
                byte[] v=c.getValue();
                int raw=v==null||v.length!=2?-32768:(short)((v[0]&255)|((v[1]&255)<<8));
                handler.post(()->finish(g,status==0 && raw>=-27315?"Lectura del sensor: "+NumberFormat.getInstance(new Locale("es","CO")).format(raw/100.0)+" °C":"Sin lectura válida del sensor."));
            }
        };
        try {
            active=device.connectGatt(activity,false,callback,BluetoothDevice.TRANSPORT_LE);
            if(active==null){message("No se pudo iniciar la conexión.");return;}
            final BluetoothGatt g=active;
            handler.postDelayed(()->finish(g,"El termómetro no respondió. Comprueba que esté encendido y cerca."),20000);
        } catch(SecurityException e){message("Permiso Bluetooth revocado.");}
    }
}
