package com.fincasannicolas.avicola;

import android.app.*;
import android.content.*;
import android.content.pm.*;
import android.net.Uri;
import android.os.Build;
import android.provider.Settings;
import android.widget.EditText;
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import javax.net.ssl.HttpsURLConnection;
import org.json.JSONObject;

final class Updates {
    private static final String MIME = "application/vnd.android.package-archive";
    private final Activity activity;
    private boolean busy;
    Updates(Activity activity) { this.activity = activity; }

    void show() {
        android.content.SharedPreferences prefs = activity.getSharedPreferences("updates", 0);
        EditText address = new EditText(activity);
        address.setInputType(android.text.InputType.TYPE_CLASS_TEXT | android.text.InputType.TYPE_TEXT_VARIATION_URI);
        address.setHint("https://…/version.json");
        address.setText(prefs.getString("manifest", ""));
        new AlertDialog.Builder(activity).setTitle("Buscar actualizaciones")
            .setMessage("Dirección oficial de actualizaciones de la finca.")
            .setView(address).setNegativeButton("Cancelar", null)
            .setPositiveButton("Buscar", (d,w) -> {
                String value = address.getText().toString().trim();
                try { https(value); }
                catch (IOException error) { message("Ingresa una dirección HTTPS válida."); return; }
                prefs.edit().putString("manifest",value).apply();
                check(value);
            }).show();
    }

    private void check(String address) {
        if (busy) return;
        busy = true;
        new Thread(() -> {
            try {
                PackageManager pm = activity.getPackageManager();
                PackageInfo installed = pm.getPackageInfo(activity.getPackageName(), PackageManager.GET_SIGNATURES);
                ByteArrayOutputStream body = new ByteArrayOutputStream();
                fetch(address, body, 16384);
                JSONObject latest = new JSONObject(new String(body.toByteArray(), StandardCharsets.UTF_8));
                int version = latest.getInt("versionCode");
                final String declaredName = latest.optString("versionName", "");
                if (version <= installed.versionCode) { done("Ya tienes la versión más reciente."); return; }
                String digest = latest.getString("sha256");
                if (!digest.matches("[0-9a-fA-F]{64}")) throw new IOException("Huella inválida");
                File temporary = new File(activity.getCacheDir(), "finca.part");
                final String displayVersion;
                try {
                    MessageDigest sha = MessageDigest.getInstance("SHA-256");
                    try (OutputStream out = new java.security.DigestOutputStream(new FileOutputStream(temporary), sha)) {
                        fetch(latest.getString("apkUrl"), out, 50000000);
                    }
                    StringBuilder hex = new StringBuilder();
                    for (byte b : sha.digest()) hex.append(String.format(java.util.Locale.ROOT,"%02x",b & 255));
                    PackageInfo next = pm.getPackageArchiveInfo(temporary.getAbsolutePath(), PackageManager.GET_SIGNATURES);
                    if (!hex.toString().equalsIgnoreCase(digest) || next == null ||
                        !installed.packageName.equals(next.packageName) || next.versionCode != version ||
                        (!declaredName.isEmpty() && !declaredName.equals(next.versionName)) ||
                        installed.signatures == null || next.signatures == null ||
                        !Arrays.equals(installed.signatures,next.signatures)) throw new IOException("Firma, paquete o versión incorrectos");
                    displayVersion = next.versionName == null || next.versionName.isEmpty() ? String.valueOf(version) : next.versionName;
                    File target = new File(activity.getCacheDir(), "finca.apk");
                    if (target.exists() && !target.delete()) throw new IOException("No se pudo preparar el archivo");
                    if (!temporary.renameTo(target)) throw new IOException("No se pudo preparar el archivo");
                } finally { temporary.delete(); }
                activity.runOnUiThread(() -> {
                    busy = false;
                    new AlertDialog.Builder(activity).setTitle("Actualización verificada")
                        .setMessage("Versión " + displayVersion + ". Android pedirá confirmar la instalación.")
                        .setNegativeButton("Después",null).setPositiveButton("Instalar",(d,w)->install()).show();
                });
            } catch (Exception error) { done("No se pudo verificar la actualización. Revisa la conexión y la dirección."); }
        }, "finca-update").start();
    }

    private void install() {
        if (Build.VERSION.SDK_INT >= 26 && !activity.getPackageManager().canRequestPackageInstalls()) {
            new AlertDialog.Builder(activity).setMessage("Permite instalar actualizaciones desde Finca San Nicolás. Luego vuelve y toca Buscar actualizaciones.")
                .setNegativeButton("Cancelar",null).setPositiveButton("Abrir ajustes",(d,w)-> {
                    try { activity.startActivity(new Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES,Uri.parse("package:"+activity.getPackageName()))); }
                    catch (ActivityNotFoundException error) { message("Android no abrió los ajustes de instalación."); }
                }).show();
            return;
        }
        Uri uri=Uri.parse("content://"+activity.getPackageName()+".update/finca.apk");
        Intent intent=new Intent(Intent.ACTION_VIEW).setDataAndType(uri,MIME).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        try { activity.startActivity(intent); }
        catch (ActivityNotFoundException error) { message("Android no abrió el instalador."); }
    }

    private static URL https(String address) throws IOException {
        URL url=new URL(address);
        if (!"https".equals(url.getProtocol()) || url.getHost().isEmpty() || url.getUserInfo()!=null) throw new IOException("Se requiere HTTPS");
        return url;
    }

    private static void fetch(String address,OutputStream out,int limit) throws IOException {
        HttpsURLConnection request=(HttpsURLConnection)https(address).openConnection();
        request.setConnectTimeout(12000);
        request.setReadTimeout(12000);
        request.setInstanceFollowRedirects(false);
        try {
            if (request.getResponseCode()!=200) throw new IOException("Descarga no disponible");
            try(InputStream in=request.getInputStream()){
                byte[] buffer=new byte[8192];
                int n,total=0;
                while((n=in.read(buffer))!=-1){
                    total+=n;
                    if(total>limit)throw new IOException("Archivo demasiado grande");
                    out.write(buffer,0,n);
                }
            }
        } finally { request.disconnect(); }
    }

    private void done(String text) { activity.runOnUiThread(() -> { busy=false; message(text); }); }
    private void message(String text) { new AlertDialog.Builder(activity).setMessage(text).setPositiveButton("Aceptar",null).show(); }
}
